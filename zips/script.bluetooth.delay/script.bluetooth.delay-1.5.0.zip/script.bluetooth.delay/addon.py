import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import os
import time
from xml.dom import minidom
import xml.parsers.expat

import sys
if sys.version > '3':
    xbmc.translatePath = xbmcvfs.translatePath

Addon = xbmcaddon.Addon('script.bluetooth.delay')

t = 1000
firstRun = Addon.getSetting('firstRun')
d1 =  float(Addon.getSetting('Device1'))
d2 =  float(Addon.getSetting('Device2'))
y = ((float(d2) * 1000) - (float(d1) * 1000)) / 25
y = int(y)
y = abs(y)
AP = Addon.getSetting('AP')
state = Addon.getSetting('state')


notiservice1 = Addon.getSetting('notiservice1')
notiservice2 = Addon.getSetting('notiservice2')
disnoti = Addon.getSetting('disnoti')


arg = None
try:
   arg = sys.argv[1].lower()
except Exception:
   pass

check = xbmc.translatePath('special://profile/guisettings.xml')

def skin1():
    time1 = os.path.getmtime(check)
    xbmc.executebuiltin('SetFocus(-73)')
    xbmc.executebuiltin("Action(select)")
    xbmc.executebuiltin('SetFocus(11)')
    xbmc.executebuiltin("Action(select)", wait=True)
    time2 = os.path.getmtime(check)
    while time2 == time1:
        time.sleep(0.01)
        time2 = os.path.getmtime(check)

def skin2():
    time1 = os.path.getmtime(check)
    xbmc.executebuiltin('SetFocus(-74)')
    xbmc.executebuiltin("Action(select)")
    xbmc.executebuiltin('SetFocus(11)')
    xbmc.executebuiltin("Action(select)", wait=True)
    time2 = os.path.getmtime(check)
    while time2 == time1:
        time.sleep(0.01)
        time2 = os.path.getmtime(check)

if "ace2" in xbmc.getSkinDir():
    skin1 = skin2
elif "aeon.nox.silvo" in xbmc.getSkinDir():
    skin1 = skin2
elif "aeon.tajo" in xbmc.getSkinDir():
    skin1 = skin2
elif "aeonmq8" in xbmc.getSkinDir():
    skin1 = skin2       
elif "ftv" in xbmc.getSkinDir():
    skin1 = skin2
elif "madnox" in xbmc.getSkinDir():
    skin1 = skin2
elif "pellucid" in xbmc.getSkinDir():
    skin1 = skin2
elif "quartz" in xbmc.getSkinDir():
     skin1 = skin2
elif "xperience1080" in xbmc.getSkinDir():
    skin1 = skin2
elif "mimic.lr" in xbmc.getSkinDir():
    skin1 = skin2


def gui():

    sourceXML = minidom.parse(xbmc.translatePath('special://profile/guisettings.xml'))
    source = sourceXML.getElementsByTagName('audiodelay')[0].firstChild.nodeValue
    source = round(.0025 * round(float(source)/.0025),3)
    return source

def noti(num):

    if disnoti == "false":

        if float(num) > 0:
            n = Addon.getLocalizedString(30021)
        elif float(num) < 0:
            n = Addon.getLocalizedString(30022)
        elif float(num) == 0:
            n = Addon.getLocalizedString(30023)

        if float(num) == -0.000:
            num = "0.000"

        if float(num) == d1:
            line = Addon.getSetting('line1')
            icon = ""
        else:
            line = Addon.getSetting('line2')
            icon = Addon.getAddonInfo('icon')

        if xbmc.getCondVisibility('Player.HasAudio'):
            num = ""
        else:
            num = (format(float(num), '.3f') + n)

        if notiservice1 == "false":
            xbmcgui.Dialog().notification(num,line, icon,t)
        Addon.setSettingBool('notiservice1', 0)


def AudioProfiles():
    if AP == "true" and notiservice2 == "false" and Addon.getSetting('AP1') and Addon.getSetting('AP2'):
        if arg == None:
            if state == "true":
                xbmc.executebuiltin("RunScript(script.audio.profiles,{})".format(Addon.getSetting('AP2')))
            else:
                xbmc.executebuiltin("RunScript(script.audio.profiles,{})".format(Addon.getSetting('AP1')))
        elif arg == "0":
           xbmc.executebuiltin("RunScript(script.audio.profiles,{})".format(Addon.getSetting('AP1')))
        elif arg == "1":
            xbmc.executebuiltin("RunScript(script.audio.profiles,{})".format(Addon.getSetting('AP2')))
    Addon.setSettingBool('notiservice2', 0)

def bluetooth():
    Addon.setSettingBool('state', 0)
    for x in range(y):
        if float(d2) > float(d1):
            xbmc.executebuiltin("Action(AudioDelayPlus)")
        if float(d2) < float(d1):
            xbmc.executebuiltin("Action(AudioDelayMinus)")

def speakers():
    Addon.setSettingBool('state', 1)
    for x in range(y):
        if float(d1) > float(d2):
            xbmc.executebuiltin("Action(AudioDelayPlus)")
        if float(d1) < float(d2):
            xbmc.executebuiltin("Action(AudioDelayMinus)")


def main():

    if arg == "setup":
        import setup
        return

    if d2 == d1:
        Addon.openSettings()
        return


    if not xbmc.getInfoLabel('Window.Property(Addon.ID)') == "script.bluetooth.delay":

        if firstRun == "false":
            if xbmcgui.Dialog().ok(Addon.getLocalizedString(30012), Addon.getLocalizedString(30014)) == True:
                Addon.setSettingBool('firstRun', 1)
            else:
                return


        if not xbmc.getCondVisibility('Player.HasVideo'):

            AudioProfiles()
            
            try:
                num = gui()
            except ImportError:
                if xbmc.getCondVisibility('system.platform.Windows'):
                    xbmc.log(msg='script.bluetooth.delay - Windows 7 error', level=xbmc.LOGDEBUG)
                    xbmcgui.Dialog().ok(Addon.getLocalizedString(30012), Addon.getLocalizedString(30015))
                    return
            

            if arg == "0":
                noti(d1)
                Addon.setSettingBool('state', 1)
                if float(num) == d1:
                    Addon.setSettingBool('service', 0)
                elif float(num) == d2:
                    Addon.setSettingBool('service', 1)

            elif arg == "1":
                noti(d2)
                Addon.setSettingBool('state', 0)
                if float(num) == d1:
                    Addon.setSettingBool('service', 1)
                elif float(num) == d2:
                    Addon.setSettingBool('service', 0)                    

            elif arg == None:
                if state == "true":
                    noti(d2)
                    Addon.setSettingBool('state', 0)
                    if float(num) == d1:
                        Addon.setSettingBool('service', 1)
                    elif float(num) == d2:
                        Addon.setSettingBool('service', 0)    
                else:
                    noti(d1)
                    Addon.setSettingBool('state', 1)
                    if float(num) == d1:
                        Addon.setSettingBool('service', 0)
                    elif float(num) == d2:
                        Addon.setSettingBool('service', 1)              
           
            return


        xbmc.executebuiltin('ActivateWindow(osdaudiosettings)')
        skin1()

        try:
            num = gui()
        except ImportError:
            if xbmc.getCondVisibility('system.platform.Windows'):
                xbmcgui.Dialog().ok(Addon.getLocalizedString(30012), Addon.getLocalizedString(30015))
                xbmc.log(msg='script.bluetooth.delay - Windows 7 error', level=xbmc.LOGDEBUG)
                return
        except xml.parsers.expat.ExpatError:
            time.sleep(2)
            num = gui()
            xbmc.log(msg='script.bluetooth.delay - minidom sleep', level=xbmc.LOGDEBUG)


        
        AudioProfiles()
        
        if float(num) == d1 or float(num) == d2:

            if arg == "0":
                if state == "true":
                    noti(num)
                    xbmc.executebuiltin("Action(close)")
                    return
                else:
                    speakers()
            
            elif arg == "1":
                if state == "true":
                    bluetooth()
                else:
                    noti(num)
                    xbmc.executebuiltin("Action(close)")
                    return

            elif arg == None:
                if state == "true":
                    bluetooth()
                else:
                    speakers()

            skin1()

            try:
                num = gui()
            except xml.parsers.expat.ExpatError:
                time.sleep(2)
                num = gui()
                xbmc.log(msg='script.bluetooth.delay - minidom sleep', level=xbmc.LOGDEBUG)

            
            noti(num)

        else:
            for x in range (800):
                xbmc.executebuiltin("Action(AudioDelayPlus)")
            for x in range (400):
                xbmc.executebuiltin("Action(AudioDelayMinus)")
            time.sleep(1)

            skin1()

            if arg == "0":
                noti(d1)
                Addon.setSettingBool('state', 1)
                xbmc.executebuiltin("Action(close)")
                return
            
            elif arg == "1":
                bluetooth()

            elif arg == None:
                if state == "true":
                    bluetooth()
                else:
                    noti(d1)
                    Addon.setSettingBool('state', 1)
                    xbmc.executebuiltin("Action(close)")
                    return

            skin1()

            try:
                num = gui()
            except xml.parsers.expat.ExpatError:
                time.sleep(2)
                num = gui()
                xbmc.log(msg='script.bluetooth.delay - minidom sleep', level=xbmc.LOGDEBUG)

            noti(num)

        xbmc.executebuiltin("Action(close)")

if __name__ == "__main__":
    main()
