from addon import *
import json


def autosetup():

    if xbmc.getCondVisibility('system.platform.Windows'):


        if xbmcgui.Dialog().ok(Addon.getLocalizedString(30200),Addon.getLocalizedString(30204)) == True:     
            pass
        else:
            return


        audioid = xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params": {"setting": "audiooutput.audiodevice"},"id": 1}')
        audioid = json.loads(audioid)
        if 'result' in audioid and 'value' in audioid['result']:
            audioid = audioid['result']['value']
            audioid = audioid.rsplit(':',1)[1]

            if audioid == "default":
                xbmcgui.Dialog().ok(Addon.getLocalizedString(30200),Addon.getLocalizedString(30205))
                return


        if sys.version > '3':
          import winreg as _winreg
        else:
          import _winreg
            
        path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\MMDevices\\Audio\\Render\\" + audioid + "\\Properties"

        name = _winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE, path, 0 ,_winreg.KEY_READ)
        name1 = _winreg.QueryValueEx(name,"{b3f8fa53-0004-438e-9003-51a46e139bfc},6")[0]
        name2 = _winreg.QueryValueEx(name,"{a45c254e-df1c-4efd-8020-67d146a850e0},2")[0]

        yes = xbmcgui.Dialog().yesno(Addon.getLocalizedString(30200),"{}{} ({})".format(Addon.getLocalizedString(30206),name1,name2))
        if yes == True:
            Addon.setSetting('audioid', audioid)
            Addon.setSetting('platform', "{} ({})".format(name1,name2))
            xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"audiooutput.audiodevice", "value":"DIRECTSOUND:default"}, "id":1}')
        else:
            xbmcgui.Dialog().ok(Addon.getLocalizedString(30200),Addon.getLocalizedString(30207))



    elif xbmc.getCondVisibility('system.platform.Android'):

        xbmc.executebuiltin('StartAndroidActivity(com.mar.btdelay,android.intent.action.MAIN)')
        
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        time.sleep(3)
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')


        path = xbmc.translatePath(Addon.getAddonInfo('path'))
        path = path.split('org.xbmc.kodi')[0] + 'com.mar.btdelay/files/'

        if os.path.exists(path):

            xbmcgui.Dialog().ok(Addon.getLocalizedString(30200),Addon.getLocalizedString(30223))
            if os.path.exists(path + "start"):
                Addon.setSetting('platform', Addon.getLocalizedString(30222))
        
        else:
            Addon.setSetting('platform', Addon.getLocalizedString(30220))

            if xbmcgui.Dialog().yesno(Addon.getLocalizedString(30200),Addon.getLocalizedString(30224)) == True:
                path = path.split('com.mar.btdelay/files/')[0] + 'com.android.vending'

                if os.path.exists(path):
                    xbmc.executebuiltin('StartAndroidActivity(com.android.vending,android.intent.action.VIEW,,https://play.google.com/store/apps/details?id=com.mar.btdelay)')
                else:
                    xbmcgui.Dialog().ok(Addon.getLocalizedString(30200),Addon.getLocalizedString(30225))


    else:
        xbmcgui.Dialog().ok(Addon.getLocalizedString(30200),Addon.getLocalizedString(30230))


autosetup()
