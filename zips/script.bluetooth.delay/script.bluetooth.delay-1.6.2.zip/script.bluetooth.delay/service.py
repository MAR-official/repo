from addon import *
import json


if xbmc.getCondVisibility('system.platform.Android'):
    try:
        xbmc.executebuiltin('StartAndroidActivity(com.mar.btdelay,android.intent.action.MAIN)')
    except:
        pass


Addon.setSettingBool('playbackstart', 0)

class Player(xbmc.Player):

    def onPlayBackStopped(self):
        Addon.setSettingBool('playbackstart', 0)

    def onAVStarted(self):
        if not xbmc.getInfoLabel('Window.Property(Addon.ID)') == "script.bluetooth.delay":
            if self.isPlayingVideo():
                service = Addon.getSetting('service')
                notiplay = Addon.getSetting('notiplay')
                playbackstart = Addon.getSetting('playbackstart')         
                if service == "true":
                    Addon.setSettingBool('notiservice2', 1)
                    state = Addon.getSetting('state')
                    if state == "true":
                        time.sleep(2)
                        Addon.setSettingBool('state', 0)
                        xbmc.executebuiltin("RunScript(script.bluetooth.delay,0)")
                    else:
                        time.sleep(2)
                        Addon.setSettingBool('state', 1)
                        xbmc.executebuiltin("RunScript(script.bluetooth.delay,1)")
                    
                    if notiplay == "false":
                        Addon.setSettingBool('notiservice1', 1)
                    else:
                        Addon.setSettingBool('playbackstart', 1)

                    Addon.setSettingBool('service', 0)

                else:

                    if notiplay == "true":
                        if playbackstart == "false":
                            Addon.setSettingBool('playbackstart', 1)
                            gui()
                            num = gui()
                            noti(num)



def autotoggle():


    if xbmc.getCondVisibility('system.platform.Windows'):
        
        if not xbmc.getInfoLabel('Window.Property(Addon.ID)') == "script.bluetooth.delay":
            auto = Addon.getSetting('auto')
            if auto == "true":

                if Addon.getSetting('audioid'):
                    audioid = Addon.getSetting('audioid')

                    if sys.version > '3':
                      import winreg as _winreg
                    else:
                      import _winreg

                    path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\MMDevices\\Audio\\Render\\" + audioid
                    try:
                        key = _winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE,path, 0 ,_winreg.KEY_READ)
                        key = _winreg.QueryValueEx(key,"DeviceState")[0]
                        key = str(key)

                        if key == "1":
                            disauto = Addon.getSetting('disauto')
                            if disauto == "false":
                                xbmc.executebuiltin("RunScript(script.bluetooth.delay,1)")
                                Addon.setSettingBool('disauto', 1)
                        else:
                            disauto = Addon.getSetting('disauto')
                            if disauto == "true":
                                xbmc.executebuiltin("RunScript(script.bluetooth.delay,0)")
                                Addon.setSettingBool('disauto', 0)
                    except WindowsError:
                        # If the id of the bluetooth headphones has changed
                        if not xbmc.getInfoLabel('Window.Property(Addon.ID)') == "script.bluetooth.delay":
                            platform = Addon.getSetting('platform')
                            if platform != str(" "):
                                Addon.setSetting('platform', " ")


    elif xbmc.getCondVisibility('system.platform.Android'):


        path = xbmc.translatePath(Addon.getAddonInfo('path'))
        path = path.split('org.xbmc.kodi')[0] + 'com.mar.btdelay/files/'


        platform = Addon.getSetting('platform')
        if os.path.exists(path):

            if os.path.exists(path + "start"):
                if platform != str(Addon.getLocalizedString(30222)):
                        Addon.setSetting('platform', Addon.getLocalizedString(30222))
            else:
                if platform != str(Addon.getLocalizedString(30221)):
                        Addon.setSetting('platform', Addon.getLocalizedString(30221))
        
        else:
            if platform != str(Addon.getLocalizedString(30220)):
                Addon.setSetting('platform', Addon.getLocalizedString(30220))



        if not xbmc.getInfoLabel('Window.Property(Addon.ID)') == "script.bluetooth.delay":
            auto = Addon.getSetting('auto')
            if auto == "true":

                if os.path.exists(path + "connected"):
                    disauto = Addon.getSetting('disauto')
                    if disauto == "false":
                        xbmc.executebuiltin("RunScript(script.bluetooth.delay,1)")
                        Addon.setSettingBool('disauto', 1)
                else:
                    disauto = Addon.getSetting('disauto')
                    if disauto == "true":
                        xbmc.executebuiltin("RunScript(script.bluetooth.delay,0)")
                        Addon.setSettingBool('disauto', 0)  


player = Player()
monitor = xbmc.Monitor()
while not monitor.abortRequested():
    autotoggle()
    monitor.waitForAbort(4)
