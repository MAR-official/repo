import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import os
import time
from xml.dom import minidom

import sys
if sys.version > '3':
    xbmc.translatePath = xbmcvfs.translatePath

Addon = xbmcaddon.Addon('script.bluetooth.delay')

t = 1000
firstRun = Addon.getSetting('firstRun')
d1 =  float(Addon.getSetting('Device1'))
d2 =  float(Addon.getSetting('Device2'))

y = ((float(d2) * 1000000) - (float(d1) * 1000000)) / 25000
y = int(y)
y = abs(y)

arg = None
try:
   arg = sys.argv[1].lower()
except Exception:
   pass

check = xbmc.translatePath('special://profile/guisettings.xml')

def skin1(s):
    time1 = os.path.getmtime(check)
    time.sleep(s)
    xbmc.executebuiltin('SetFocus(-73)')
    xbmc.executebuiltin("Action(select)")
    xbmc.executebuiltin('SetFocus(11)')
    xbmc.executebuiltin("Action(select)", wait=True)
    time2 = os.path.getmtime(check)
    while time2 == time1:
        time.sleep(0.01)
        time2 = os.path.getmtime(check)

def skin2(s):
    time1 = os.path.getmtime(check)
    time.sleep(s)
    xbmc.executebuiltin('SetFocus(-74)')
    xbmc.executebuiltin("Action(select)")
    xbmc.executebuiltin('SetFocus(11)')
    xbmc.executebuiltin("Action(select)", wait=True)
    time2 = os.path.getmtime(check)
    while time2 == time1:
        time.sleep(0.01)
        time2 = os.path.getmtime(check)

if "ace2" in xbmc.getSkinDir():
    skin1 = skin2
elif "aeon.nox.silvo" in xbmc.getSkinDir():
    skin1 = skin2
elif "aeon.tajo" in xbmc.getSkinDir():
    skin1 = skin2
elif "aeonmq8" in xbmc.getSkinDir():
    skin1 = skin2       
elif "ftv" in xbmc.getSkinDir():
    skin1 = skin2
elif "madnox" in xbmc.getSkinDir():
    skin1 = skin2
elif "pellucid" in xbmc.getSkinDir():
    skin1 = skin2
elif "quartz" in xbmc.getSkinDir():
     skin1 = skin2
elif "xperience1080" in xbmc.getSkinDir():
    skin1 = skin2
elif "mimic.lr" in xbmc.getSkinDir():
    skin1 = skin2


def gui():

    sourceXML = minidom.parse(xbmc.translatePath('special://profile/guisettings.xml'))
    source = sourceXML.getElementsByTagName('audiodelay')[0].firstChild.nodeValue
    source = round(.0025000 * round(float(source)/.0025000),6)
    return source

def noti(num):

    if float(num) > 0:
        n = Addon.getLocalizedString(30021)
    elif float(num) < 0:
        n = Addon.getLocalizedString(30022)
    elif float(num) == 0:
        n = Addon.getLocalizedString(30023)

    if float(num) == -0.000000:
        num = "0.000000"

    if float(num) == d1:
        line = Addon.getSetting('line1')
    else:
        line = Addon.getSetting('line2')

    xbmcgui.Dialog().notification(format(float(num), '.3f') + n,line, "",t)


def main():

    if d2 == d1:
        if firstRun == "false":
            xbmcgui.Dialog().ok(Addon.getLocalizedString(30013), Addon.getLocalizedString(30014))
            Addon.setSettingBool('firstRun', 1)
        Addon.openSettings()
        return

    elif (xbmc.getCondVisibility('Player.HasVideo') == False):
        xbmcgui.Dialog().notification("",Addon.getLocalizedString(30015), "",t)
        return

    xbmc.executebuiltin('ActivateWindow(osdaudiosettings)')
    skin1(0)
    gui()
    num = gui()

    if float(num) == d1:
        if arg == None or arg == "1":
            for x in range(y):
                if float(d2) > float(d1):
                    xbmc.executebuiltin("Action(AudioDelayPlus)")
                if float(d2) < float(d1):
                    xbmc.executebuiltin("Action(AudioDelayMinus)")

            skin1(float(Addon.getSetting('Mode')))
            gui()
            num = gui()
            noti(num)

        elif arg == "0":
            noti(num)
 
    elif float(num) == d2:
        if arg == None or arg == "0":
            for x in range(y):
                if float(d1) > float(d2):
                    xbmc.executebuiltin("Action(AudioDelayPlus)")
                if float(d1) < float(d2):
                    xbmc.executebuiltin("Action(AudioDelayMinus)")

            skin1(float(Addon.getSetting('Mode')))
            gui()
            num = gui()
            noti(num)

        elif arg == "1":
            noti(num)

    else:
        for x in range (800):
            xbmc.executebuiltin("Action(AudioDelayPlus)")
        for x in range (400):
            xbmc.executebuiltin("Action(AudioDelayMinus)")
        xbmc.executebuiltin('ActivateWindow(osdaudiosettings)')
        time.sleep(1)

        skin1(float(Addon.getSetting('Mode')))
        gui()       
        num = gui()
        noti(num)

    xbmc.executebuiltin("Action(close)")

main()
